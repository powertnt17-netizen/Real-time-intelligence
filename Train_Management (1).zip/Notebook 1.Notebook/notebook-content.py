# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "65564c8b-738e-4a08-bcf2-d1f8c10c659c",
# META       "default_lakehouse_name": "Variáveis_lentas",
# META       "default_lakehouse_workspace_id": "d0a7ce6c-5e15-4453-9a79-a3dce6fd7df6",
# META       "known_lakehouses": [
# META         {
# META           "id": "65564c8b-738e-4a08-bcf2-d1f8c10c659c"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

# --- PASSO 1: CRIAR A TABELA DIMENSÃO (CATÁLOGO DA FROTA) ---

# Criar uma lista vazia para guardar a nossa frota
frota_data = []

# Como sabemos que tens 500 comboios com 10 carruagens cada:
for i in range(1, 501):
    for j in range(1, 11):
        # Criar uma chave única (ex: "1-1") e um nome bonito para o Power BI
        chave_unica = f"{i}-{j}"
        nome_visor = f"Comboio {i:03d} | Carruagem {j:02d}"
        
        frota_data.append((str(i), str(j), chave_unica, nome_visor))

# Converter a lista num DataFrame do Spark
df_frota = spark.createDataFrame(frota_data, ["Comboio", "Carruagem", "Chave_Ativo", "Nome_Display"])

# Guardar esta tabela no teu Lakehouse como uma tabela Delta (Camada Gold)
df_frota.write.format("delta").mode("overwrite").saveAsTable("Dim_Frota")

# Mostrar as primeiras linhas para confirmar
display(df_frota.limit(5))


# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
