# Fabric notebook source

# METADATA ********************

# META {
# META   "kernel_info": {
# META     "name": "synapse_pyspark"
# META   },
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "65564c8b-738e-4a08-bcf2-d1f8c10c659c",
# META       "default_lakehouse_name": "Variáveis_lentas",
# META       "default_lakehouse_workspace_id": "d0a7ce6c-5e15-4453-9a79-a3dce6fd7df6",
# META       "known_lakehouses": [
# META         {
# META           "id": "65564c8b-738e-4a08-bcf2-d1f8c10c659c"
# META         }
# META       ]
# META     }
# META   }
# META }

# CELL ********************

from pyspark.sql import functions as F
from pyspark.sql.window import Window

# 1. LER DA TABELA BRUTA
df_stream = spark.readStream.table("dbo.variaveisraw") \
    .filter("Tipo_de_Evento IN ('Temperature', 'Humidity', 'Door Open', 'Lights')")

# 2. A TUA CORREÇÃO: Particionar por Comboio, Carruagem e Equipamento!
window_spec = Window.partitionBy("Comboio", "Carruagem", "ID_Equipamento").orderBy("Datahora_Evento")

def process_batch(batch_df, batch_id):
    if batch_df.isEmpty():
        return

    # Compara o valor com a mesma carruagem e mesmo comboio
    enriched_df = batch_df.withColumn("prev_valor", F.lag("Valor").over(window_spec)) \
                          .filter("Valor != prev_valor OR prev_valor IS NULL") \
                          .drop("prev_valor")

    # 3. ESCREVER NA TABELA
    enriched_df.write \
        .format("delta") \
        .mode("append") \
        .option("mergeSchema", "true") \
        .saveAsTable("dbo.tabela_variaveis_lentas_filtrada")

# 4. ARRANCAR O MOTOR (Checkpoint V4)
query = df_stream.writeStream \
    .foreachBatch(process_batch) \
    .option("checkpointLocation", "Files/checkpoints/train_fleet_v4") \
    .start()
    
    # 5. MANTER O SERVIDOR LIGADO 24/7
query.awaitTermination()

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }

# CELL ********************

display(spark.sql("SELECT * FROM dbo.variaveisraw ORDER BY Datahora_Evento DESC LIMIT 20"))

# METADATA ********************

# META {
# META   "language": "python",
# META   "language_group": "synapse_pyspark"
# META }
